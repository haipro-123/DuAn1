/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication24.view;

/**
 *
 * @author Administrator
 */
public class TaoID {
    public static String idDVVC="";
      public static String idHD="";

    public TaoID() {
    }

 
    public static String getIdDVVC() {
        return idDVVC;
    }

    public static void setIdDVVC(String idDVVC) {
        TaoID.idDVVC = idDVVC;
    }

    public static String getIdHD() {
        return idHD;
    }

    public static void setIdHD(String idHD) {
        TaoID.idHD = idHD;
    }
    
    
}
