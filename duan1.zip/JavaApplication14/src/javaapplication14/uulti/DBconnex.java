/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication14.uulti;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class DBconnex {

    private static String usename = "sa";
    private static String password = "123456";
    private static String url = "jdbc:sqlserver://DESKTOP-LLTD96A\\\\SQLEXPRESS:1433;databaseName=QLSach";


 static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBconnex.class.getName()).log(Level.SEVERE, null, ex);
        }
        }

    public static Connection getConnection() {
        Connection cn = null;
        try {
            cn = DriverManager.getConnection(url, usename, password);
        } catch (Exception ex) {
            Logger.getLogger(DBconnex.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cn;
    }

    public static void main(String[] args) {
        Connection cn = getConnection();
        if (cn != null) {
            System.out.println("thành công!");
        } else {
            System.out.println("lỗi");
        }

    }
}
