/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication24.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javaapplication24.model.DonGiaoChiTiet;

/**
 *
 * @author Administrator
 */
public class DonGiaoCTRepo {

    private Connection conn;

    public DonGiaoCTRepo() {
        conn = DBconnect.getConnection();

    }

    public boolean update(DonGiaoChiTiet dgct) {

        try {

            String sql = "Update donGiaoChiTiet set idDonGiao=?,idHoaDon=?,idDonViVanChuyen=?,ngayGiaoHang=?,ngayNhanHang=?,tinhTrang=? where idDonGiaoChiTiet=?";
            PreparedStatement ps = conn.prepareStatement(sql);

              ps.setString(1, dgct.getIdDonGiao());
            ps.setString(2, dgct.getIdHoaDon());
             ps.setString(3, dgct.getIdDonViVanChuyen());
              ps.setString(4, dgct.getNgayGiaoHang());
               ps.setString(5, dgct.getNgayNhanHang());
                ps.setInt(6, dgct.getTinhTrang());
                   ps.setString(1, dgct.getIdDonGiaoChiTiet());
            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public boolean delete(DonGiaoChiTiet dgct) {

        try {

            String sql = "Delete donGiaoChiTiet where idDonGiaoChiTiet=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, dgct.getIdDonGiaoChiTiet());

            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public boolean insert(DonGiaoChiTiet dgct) {

        try {

            String sql = "Insert into donGiaoChiTiet(idDonGiao,idHoaDon,idDonViVanChuyen,ngayGiaoHang,ngayNhanHang,tinhTrang) values(?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, dgct.getIdDonGiao());
            ps.setString(2, dgct.getIdHoaDon());
             ps.setString(3, dgct.getIdDonViVanChuyen());
              ps.setString(4, dgct.getNgayGiaoHang());
               ps.setString(5, dgct.getNgayNhanHang());
                ps.setInt(6, dgct.getTinhTrang());
              
                 
                 

            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public List<DonGiaoChiTiet> all() {

        List<DonGiaoChiTiet> ds = new ArrayList<>();
        try {

            String sql = "Select idDonGiaoChiTiet,donGiaoChiTiet.idDonGiao,donGiaoChiTiet.idHoaDon,donGiaoChiTiet.idDonViVanChuyen,donGiao.MaDG as maDG,hoaDon.ma as maHD,DonViVanChuyen.maDVVC as maDVVC,DonViVanChuyen.ten as tenDVVC,donGiaoChiTiet.ngayGiaoHang,donGiaoChiTiet.ngayNhanHang,donGiaoChiTiet.tinhTrang\n"
                    + "from donGiaoChiTiet join donGiao on donGiaoChiTiet.idDonGiao = donGiao.idDonGiao join DonViVanChuyen on DonViVanChuyen.iddonViVanChuyen= donGiaoChiTiet.idDonViVanChuyen join hoaDon on donGiaoChiTiet.idHoaDon=hoaDon.idHoaDon";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                String idDonGiaoCT = rs.getString("idDonGiaoChiTiet");
                String idDonGiao = rs.getString("idDonGiao");
                String idHoaDon = rs.getString("idHoaDon");
                String idDVVC = rs.getString("idDonViVanChuyen");
                String maDG = rs.getString("maDG");
                String maHD = rs.getString("maHD");
                String maDVVC = rs.getString("maDVVC");
                String tenDVVC = rs.getString("tenDVVC");
                String ngayGiao = rs.getString("ngayGiaoHang");
                String ngayNhan = rs.getString("ngayNhanHang");
                int tinhTrang = rs.getInt("tinhTrang");

                DonGiaoChiTiet dgct = new DonGiaoChiTiet(idDonGiaoCT, idDonGiao, idHoaDon, idDVVC, maDG, maHD, maDVVC, tenDVVC, ngayGiao, ngayNhan, tinhTrang);
                ds.add(dgct);
            }
            System.out.println("Thành công");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
        }
        return ds;
    }

}
