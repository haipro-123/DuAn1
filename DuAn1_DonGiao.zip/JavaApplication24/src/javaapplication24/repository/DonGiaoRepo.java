/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication24.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javaapplication24.model.DonGiao;

/**
 *
 * @author Administrator
 */
public class DonGiaoRepo {
     private Connection conn;

    public DonGiaoRepo() {
        conn = DBconnect.getConnection();

    }

    public boolean update(DonGiao dg) {

        try {

            String sql = "Update donGiao set MaDG=?,Mota=? where idDonGiao=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, dg.getMa());
            ps.setString(2, dg.getMoTa());
            ps.setString(3, dg.getId());
            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public boolean delete(DonGiao dg) {

        try {

            String sql = "Delete donGiao where idDonGiao=?";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, dg.getId());

            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public boolean insert(DonGiao dg) {

        try {

            String sql = "Insert into donGiao(MaDG,MoTa) values(?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, dg.getMa());
            ps.setString(2, dg.getMoTa());

            ps.execute();
            System.out.println("Thành công");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
            return false;
        }

    }

    public List<DonGiao> all() {

        List<DonGiao> ds = new ArrayList<>();
        try {

            String sql = "Select * from donGiao";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.execute();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                String id = rs.getString("idDonGiao");
                String ma = rs.getString("MaDG");
                String moTa = rs.getString("MoTa");

                DonGiao dg = new DonGiao(id,ma, moTa);
                ds.add(dg);
            }
            System.out.println("Thành công");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Thất bại");
        }
        return ds;
    }
    
}
