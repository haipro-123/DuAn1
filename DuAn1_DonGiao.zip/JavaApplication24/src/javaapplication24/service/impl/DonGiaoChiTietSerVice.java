/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication24.service.impl;

import java.util.ArrayList;
import java.util.List;
import javaapplication24.model.DonGiao;
import javaapplication24.model.DonGiaoChiTiet;
import javaapplication24.repository.DonGiaoCTRepo;
import javaapplication24.repository.DonGiaoRepo;
import javaapplication24.viewmodel.DonGiaoChiTietViewModel;
import javaapplication24.viewmodel.DonGiaoViewModel;

/**
 *
 * @author Administrator
 */
public class DonGiaoChiTietSerVice {
   private javaapplication24.repository.DonGiaoCTRepo donGiaoCTRepo;

    public DonGiaoChiTietSerVice() {
        this.donGiaoCTRepo= new DonGiaoCTRepo();
    }
    
    public boolean insert( DonGiaoChiTietViewModel ql ){
        DonGiaoChiTiet dgct = new DonGiaoChiTiet("", ql.getIdDonGiao(), ql.getIdHoaDon(),ql.getIdDonViVanChuyen(),"","","","",ql.getNgayGiaoHang(),ql.getNgayNhanHang(),ql.getTinhTrang());
       
          return donGiaoCTRepo.insert(dgct) ;
        }
  
    public boolean update( DonGiaoChiTietViewModel ql ){
       DonGiaoChiTiet dgct = new DonGiaoChiTiet(ql.getIdDonGiaoChiTiet(), ql.getMaDonGiao(), ql.getIdHoaDon(),ql.getIdDonViVanChuyen(),"","","","",ql.getNgayGiaoHang(),ql.getNgayNhanHang(),ql.getTinhTrang());
       
          return donGiaoCTRepo.update(dgct) ;
        }
    public boolean delete( DonGiaoChiTietViewModel ql ){
       DonGiaoChiTiet dgct = new DonGiaoChiTiet(ql.getIdDonGiaoChiTiet(),"","","","","","","","","",0);
       
          return donGiaoCTRepo.delete(dgct) ;
        }
   
    public List<DonGiaoChiTietViewModel> all(){
        List<DonGiaoChiTietViewModel> ds = new ArrayList<>();
        List<DonGiaoChiTiet> list = donGiaoCTRepo.all();
        for (DonGiaoChiTiet dg : list) {
            DonGiaoChiTietViewModel ql = new DonGiaoChiTietViewModel(dg.getIdDonGiaoChiTiet(), dg.getIdDonGiao(), dg.getIdHoaDon(),dg.getIdDonViVanChuyen(),dg.getMaDonGiao(),dg.getMaHoaDon(),dg.getMaDVVC(),dg.getTenDVVC(),dg.getNgayGiaoHang(),dg.getNgayNhanHang(),dg.getTinhTrang());
            ds.add(ql);
        }
     return ds;
    }
}
