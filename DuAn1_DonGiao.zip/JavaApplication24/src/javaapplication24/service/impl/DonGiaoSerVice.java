/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication24.service.impl;

import java.util.ArrayList;
import java.util.List;
import javaapplication24.model.DonGiao;
import javaapplication24.repository.DonGiaoRepo;
import javaapplication24.viewmodel.DonGiaoViewModel;

/**
 *
 * @author Administrator
 */
public class DonGiaoSerVice {
   private javaapplication24.repository.DonGiaoRepo donGiaoRepo;

    public DonGiaoSerVice() {
        this.donGiaoRepo= new DonGiaoRepo();
    }
    
    public boolean insert( DonGiaoViewModel ql ){
       DonGiao dg = new DonGiao("", ql.getMa(), ql.getMoTa());
       
          return donGiaoRepo.insert(dg) ;
        }
  
    public boolean update( DonGiaoViewModel ql ){
       DonGiao dg = new DonGiao(ql.getId(), ql.getMa(), ql.getMoTa());
       
          return donGiaoRepo.update(dg) ;
        }
    public boolean delete( DonGiaoViewModel ql ){
       DonGiao dg = new DonGiao(ql.getId(), ql.getMa(), ql.getMoTa());
       
          return donGiaoRepo.delete(dg) ;
        }
   
    public List<DonGiaoViewModel> all(){
        List<DonGiaoViewModel> ds = new ArrayList<>();
        List<DonGiao> list = donGiaoRepo.all();
        for (DonGiao dg : list) {
            DonGiaoViewModel ql = new DonGiaoViewModel(dg.getId(), dg.getMa(), dg.getMoTa());
            ds.add(ql);
        }
     return ds;
    }
}
