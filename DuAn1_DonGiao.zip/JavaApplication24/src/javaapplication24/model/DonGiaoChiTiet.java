
package javaapplication24.model;


public class DonGiaoChiTiet {
 private String   idDonGiaoChiTiet;
  private String   idDonGiao;
   private String  idHoaDon;
 private String    idDonViVanChuyen;
 private String   maDonGiao;
   private String  maHoaDon;
 private String    maDVVC;
  private String    tenDVVC;
  private String   ngayGiaoHang;
 private String    ngayNhanHang;
 private int    tinhTrang;

    public DonGiaoChiTiet() {
    }

    public DonGiaoChiTiet(String idDonGiaoChiTiet, String idDonGiao, String idHoaDon, String idDonViVanChuyen, String maDonGiao, String maHoaDon, String maDVVC, String tenDVVC, String ngayGiaoHang, String ngayNhanHang, int tinhTrang) {
        this.idDonGiaoChiTiet = idDonGiaoChiTiet;
        this.idDonGiao = idDonGiao;
        this.idHoaDon = idHoaDon;
        this.idDonViVanChuyen = idDonViVanChuyen;
        this.maDonGiao = maDonGiao;
        this.maHoaDon = maHoaDon;
        this.maDVVC = maDVVC;
        this.tenDVVC = tenDVVC;
        this.ngayGiaoHang = ngayGiaoHang;
        this.ngayNhanHang = ngayNhanHang;
        this.tinhTrang = tinhTrang;
    }

    public String getIdDonGiaoChiTiet() {
        return idDonGiaoChiTiet;
    }

    public void setIdDonGiaoChiTiet(String idDonGiaoChiTiet) {
        this.idDonGiaoChiTiet = idDonGiaoChiTiet;
    }

    public String getIdDonGiao() {
        return idDonGiao;
    }

    public void setIdDonGiao(String idDonGiao) {
        this.idDonGiao = idDonGiao;
    }

    public String getIdHoaDon() {
        return idHoaDon;
    }

    public void setIdHoaDon(String idHoaDon) {
        this.idHoaDon = idHoaDon;
    }

    public String getIdDonViVanChuyen() {
        return idDonViVanChuyen;
    }

    public void setIdDonViVanChuyen(String idDonViVanChuyen) {
        this.idDonViVanChuyen = idDonViVanChuyen;
    }

    public String getMaDonGiao() {
        return maDonGiao;
    }

    public void setMaDonGiao(String maDonGiao) {
        this.maDonGiao = maDonGiao;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public String getMaDVVC() {
        return maDVVC;
    }

    public void setMaDVVC(String maDVVC) {
        this.maDVVC = maDVVC;
    }

    public String getTenDVVC() {
        return tenDVVC;
    }

    public void setTenDVVC(String tenDVVC) {
        this.tenDVVC = tenDVVC;
    }

    public String getNgayGiaoHang() {
        return ngayGiaoHang;
    }

    public void setNgayGiaoHang(String ngayGiaoHang) {
        this.ngayGiaoHang = ngayGiaoHang;
    }

    public String getNgayNhanHang() {
        return ngayNhanHang;
    }

    public void setNgayNhanHang(String ngayNhanHang) {
        this.ngayNhanHang = ngayNhanHang;
    }

    public int getTinhTrang() {
        return tinhTrang;
    }

    public void setTinhTrang(int tinhTrang) {
        this.tinhTrang = tinhTrang;
    }
 
    
}
