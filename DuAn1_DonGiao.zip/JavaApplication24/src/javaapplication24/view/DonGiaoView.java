
package javaapplication24.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javaapplication24.model.HoaDon;
import javaapplication24.service.impl.DonGiaoChiTietSerVice;
import javaapplication24.service.impl.DonGiaoSerVice;
import javaapplication24.service.impl.DonViVanChuyenSerVice;
import javaapplication24.service.impl.HoaDonSerVice;
import javaapplication24.viewmodel.DonGiaoChiTietViewModel;
import javaapplication24.viewmodel.DonGiaoViewModel;
import javaapplication24.viewmodel.DonViVanChuyenViewModel;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class DonGiaoView extends javax.swing.JPanel {

    private javaapplication24.service.impl.DonGiaoSerVice donGiaoSerVice;
    private javaapplication24.service.impl.DonViVanChuyenSerVice donViVanChuyenSerVice;
    private javaapplication24.service.impl.DonGiaoChiTietSerVice donGiaoChiTietSerVice;
    private javaapplication24.service.impl.HoaDonSerVice hoaDonSerVice;

    public DonGiaoView() {
        
        initComponents();
        donGiaoSerVice = new DonGiaoSerVice();
        donViVanChuyenSerVice = new DonViVanChuyenSerVice();
        donGiaoChiTietSerVice = new DonGiaoChiTietSerVice();
        hoaDonSerVice = new HoaDonSerVice();
        loadTableDG();
        loadTableDVVC();
        loadTableDGCT();
        fillCboIdDVVC();
        fillCboIdDG();
        fillCboIdHD();
    }
    
    public boolean ValidateDG(){
        if(txtMaDG.getText().equals("")||txtMoTa.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Không được để trống");
            return false;
        }
       return true;
    }
    
    public boolean ValidateDVVC(){
        if(txtMa.getText().equals("")||txtTen.getText().equals("")||txtPhamViVC.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Không được để trống");
            return false;
        }
       return true;
    }
    
      public boolean ValidateDGCT(){
        if(txtNgayGiao.getText().equals("")||txtNgayNhan.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Không được để trống");
            return false;
        }
        
          SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
          sdf.setLenient(false);
          try {
              Date giao = sdf.parse(txtNgayGiao.getText());
                Date nhan = sdf.parse(txtNgayNhan.getText());
          } catch (ParseException e) {
              JOptionPane.showMessageDialog(this, "Không đúng định dạng (Năm-Tháng-Ngày)");
              return false;
          }
        
          return true;
    }
    public void fillCboIdDVVC() {
        List<DonViVanChuyenViewModel> ds = donViVanChuyenSerVice.all();
        for (DonViVanChuyenViewModel ql : ds) {
            String idDVVC = ql.getIdDVVC();
            cboDVVC.addItem(idDVVC);
        }
    }
    
    public void fillCboIdDG() {
        
        List<DonGiaoViewModel> ds = donGiaoSerVice.all();
        for (DonGiaoViewModel ql : ds) {
            
            String idDG = ql.getId();
            cboDG.addItem(idDG);
            
        }
    }

    public void fillCboIdHD() {
        
        List<HoaDon> ds = hoaDonSerVice.all();
        for (HoaDon ql : ds) {
            
            String idHD = ql.getIdHoaDon();
            cboHoaDon.addItem(idHD);
            
        }
        
    }

    public void loadTableDGCT() {
        DefaultTableModel dtm = (DefaultTableModel) tblDGCT.getModel();
        
        dtm.setRowCount(0);
        List<DonGiaoChiTietViewModel> ds = donGiaoChiTietSerVice.all();
        for (DonGiaoChiTietViewModel ql : ds) {
            Object[] rowData = new Object[]{
                ql.getIdDonGiaoChiTiet(),
                ql.getIdDonGiao(),
                ql.getIdHoaDon(),
                ql.getIdDonViVanChuyen(),
                ql.getMaDonGiao(),
                ql.getMaHoaDon(),
                ql.getMaDVVC(),
                ql.getTenDVVC(),
                ql.getNgayGiaoHang(),
                ql.getNgayNhanHang(),
                ql.getTinhTrang() == 1 ? "Nhận hàng" : "Hủy hàng"
            
            };
            dtm.addRow(rowData);
            
        }
    }

    public void loadTableDVVC() {
        DefaultTableModel dtm = (DefaultTableModel) tblDVVC.getModel();
        dtm.setRowCount(0);
        List<DonViVanChuyenViewModel> ds = donViVanChuyenSerVice.all();
        for (DonViVanChuyenViewModel ql : ds) {
            Object[] rowData = new Object[]{
                ql.getIdDVVC(),
                ql.getMa(),
                ql.getTen(),
                ql.getPhamViVC(),
                ql.getTrangThai() == 1 ? "Hoạt Động" : "Ngừng Hoạt Động"
            };
            dtm.addRow(rowData);
            
        }
    }

    public void loadTableDG() {
        DefaultTableModel dtm = (DefaultTableModel) tblDG.getModel();
        dtm.setRowCount(0);
        List<DonGiaoViewModel> ds = donGiaoSerVice.all();
        for (DonGiaoViewModel ql : ds) {
            Object[] rowData = new Object[]{
                ql.getId(),
                ql.getMa(),
                ql.getMoTa()
            };
            dtm.addRow(rowData);
            
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane4 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lbIdDGCT = new javax.swing.JLabel();
        cboDG = new javax.swing.JComboBox<>();
        cboHoaDon = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        cboDVVC = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtNgayGiao = new javax.swing.JTextField();
        txtNgayNhan = new javax.swing.JTextField();
        rdoNhanHang = new javax.swing.JRadioButton();
        rdoHuyHang = new javax.swing.JRadioButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblDGCT = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        btnThemDGCT = new javax.swing.JButton();
        btnXoaDGCT = new javax.swing.JButton();
        btnSuaDGCT = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lbID = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtMa = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTen = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtPhamViVC = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        rdoHD = new javax.swing.JRadioButton();
        rdoNgungHD = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        btnThemDVVC = new javax.swing.JButton();
        btnSuaDVVC = new javax.swing.JButton();
        btnXoaDVVC = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDVVC = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtMaDG = new javax.swing.JTextField();
        txtMoTa = new javax.swing.JTextField();
        lbIdDonGiao = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        btnThemDG = new javax.swing.JButton();
        btnSuaDG = new javax.swing.JButton();
        btnXoaDG = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblDG = new javax.swing.JTable();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane4.setViewportView(jTable2);

        jPanel6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setText("Id");

        jLabel7.setText("idDG");

        jLabel8.setText("idHD");

        cboDG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "chọn id" }));

        cboHoaDon.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "chọn id" }));

        jLabel12.setText("IdDVVC");

        cboDVVC.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "chọn id " }));
        cboDVVC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboDVVCActionPerformed(evt);
            }
        });

        jLabel13.setText("Ngày Giao");

        jLabel14.setText("Ngày Nhận");

        jLabel15.setText("Tình Trạng");

        buttonGroup3.add(rdoNhanHang);
        rdoNhanHang.setText("Nhận Hàng");

        buttonGroup3.add(rdoHuyHang);
        rdoHuyHang.setText("Hủy Hàng");
        rdoHuyHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoHuyHangActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbIdDGCT, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cboHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(cboDG, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cboDVVC, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(73, 73, 73)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel14)
                                .addComponent(jLabel13)))
                        .addGap(14, 14, 14)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(rdoNhanHang, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdoHuyHang, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNgayGiao, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNgayNhan, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbIdDGCT, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cboDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(txtNgayGiao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(cboHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(txtNgayNhan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboDVVC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel15)
                    .addComponent(rdoNhanHang)
                    .addComponent(rdoHuyHang))
                .addGap(42, 42, 42))
        );

        jPanel8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tblDGCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "idDG", "idHoaDon", "idDVVC", "Mã Đơn Giao", "Mã Hóa Đơn", "Mã Đơn Vị VC", "tên DVVC", "Ngày Giao", "Ngày Nhận", "Tình Trạng"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDGCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDGCTMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblDGCT);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnThemDGCT.setText("Thêm");
        btnThemDGCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDGCTActionPerformed(evt);
            }
        });

        btnXoaDGCT.setText("Xóa");
        btnXoaDGCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaDGCTActionPerformed(evt);
            }
        });

        btnSuaDGCT.setText("Sửa ");
        btnSuaDGCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDGCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSuaDGCT, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(btnThemDGCT, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaDGCT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnThemDGCT, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btnSuaDGCT, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(btnXoaDGCT, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 3, Short.MAX_VALUE)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Đơn Giao Chi Tiết", jPanel2);

        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setText("Id");

        jLabel3.setText("Mã");

        jLabel4.setText("Tên");

        jLabel5.setText("Phạm vi VC ");

        jLabel6.setText("Trạng Thái");

        buttonGroup1.add(rdoHD);
        rdoHD.setText("Hoạt động");

        buttonGroup1.add(rdoNgungHD);
        rdoNgungHD.setText("Ngừng Hoạt động");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdoHD)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdoNgungHD)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPhamViVC, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(79, 79, 79))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1))
                            .addComponent(jLabel3))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbID, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lbID, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtMa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtPhamViVC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(rdoHD)
                    .addComponent(rdoNgungHD))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnThemDVVC.setText("Thêm");
        btnThemDVVC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDVVCActionPerformed(evt);
            }
        });

        btnSuaDVVC.setText("Sửa");
        btnSuaDVVC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDVVCActionPerformed(evt);
            }
        });

        btnXoaDVVC.setText("Xóa");
        btnXoaDVVC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaDVVCActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnThemDVVC, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
                    .addComponent(btnSuaDVVC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaDVVC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnThemDVVC, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnSuaDVVC, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(btnXoaDVVC, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tblDVVC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Mã", "Tên", "Phạm Vi VC", "Trạng Thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, true, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDVVC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDVVCMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblDVVC);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 651, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Đơn vị vận chuyển", jPanel1);

        jPanel10.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel9.setText("ID");

        jLabel10.setText("Mã Đơn Giao");

        jLabel11.setText("Mô Tả");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(lbIdDonGiao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                        .addComponent(txtMaDG, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(77, 77, 77)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(txtMoTa, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbIdDonGiao, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(23, 23, 23)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(txtMaDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtMoTa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnThemDG.setText("Thêm");
        btnThemDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDGActionPerformed(evt);
            }
        });

        btnSuaDG.setText("Sửa");
        btnSuaDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDGActionPerformed(evt);
            }
        });

        btnXoaDG.setText("Xóa");
        btnXoaDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaDGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThemDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSuaDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnThemDG, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSuaDG, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnXoaDG, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tblDG.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Mã Đơn Giao", "Mô Tả"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDG.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDGMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblDG);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 641, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Đơn Giao", jPanel7);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cboDVVCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboDVVCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboDVVCActionPerformed

    private void rdoHuyHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoHuyHangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdoHuyHangActionPerformed

    private void btnThemDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDGActionPerformed
     if(ValidateDG()){
        String ma = txtMaDG.getText();
        String moTa = txtMoTa.getText();
        donGiaoSerVice.insert(new DonGiaoViewModel("", ma, moTa));
        JOptionPane.showMessageDialog(this, "Thêm thành công");
        this.loadTableDG();}
    }//GEN-LAST:event_btnThemDGActionPerformed

    private void tblDGMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDGMouseClicked
        int row = tblDG.getSelectedRow();
        if (row == -1) {
            return;
        }
        String id = tblDG.getValueAt(row, 0).toString();
        String ma = tblDG.getValueAt(row, 1).toString();
        String moTa = tblDG.getValueAt(row, 2).toString();
        
        lbIdDonGiao.setText(id);
        txtMaDG.setText(ma);
        txtMoTa.setText(moTa);
        
    }//GEN-LAST:event_tblDGMouseClicked

    private void btnSuaDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDGActionPerformed
      if(ValidateDG()){  String id = lbIdDonGiao.getText();
        String ma = txtMaDG.getText();
        String moTa = txtMoTa.getText();
        donGiaoSerVice.update(new DonGiaoViewModel(id, ma, moTa));
        JOptionPane.showMessageDialog(this, "Sửa thành công");
        this.loadTableDG();}
    }//GEN-LAST:event_btnSuaDGActionPerformed

    private void btnXoaDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaDGActionPerformed
        String id = lbIdDonGiao.getText();
        donGiaoSerVice.delete(new DonGiaoViewModel(id, "", ""));
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa ko?");
        if(confirm!=JOptionPane.YES_OPTION){
            return;
        }
        JOptionPane.showMessageDialog(this, "Xóa thành công");
        this.loadTableDG();
    }//GEN-LAST:event_btnXoaDGActionPerformed

    private void tblDVVCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDVVCMouseClicked
        int row = tblDVVC.getSelectedRow();
        if (row == -1) {
            return;
        }
        String id = tblDVVC.getValueAt(row, 0).toString();
        String ma = tblDVVC.getValueAt(row, 1).toString();
        String ten = tblDVVC.getValueAt(row, 2).toString();
        String pvi = tblDVVC.getValueAt(row, 3).toString();
        String trangThai = tblDVVC.getValueAt(row, 4).toString();
        
        lbID.setText(id);
        txtMa.setText(ma);
        txtTen.setText(ten);
        txtPhamViVC.setText(pvi);
        if (trangThai.equals("Hoạt Động")) {
            rdoHD.setSelected(true);
        } else {
            rdoNgungHD.setSelected(true);
        }
        
    }//GEN-LAST:event_tblDVVCMouseClicked

    private void btnThemDVVCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDVVCActionPerformed
      if(ValidateDVVC()) { String ma = txtMa.getText();
        String ten = txtTen.getText();
        String pvi = txtPhamViVC.getText();
        int trangThai;
        if (rdoHD.isSelected()) {
            trangThai = 1;
        } else {
            trangThai = 0;
            
        }
        donViVanChuyenSerVice.insert(new DonViVanChuyenViewModel("", ma, ten, pvi, trangThai));
        JOptionPane.showMessageDialog(this, "Thêm thành công");
        this.loadTableDVVC();}
    }//GEN-LAST:event_btnThemDVVCActionPerformed

    private void btnSuaDVVCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDVVCActionPerformed
       if(ValidateDVVC()){ String id = lbID.getText();
        String ma = txtMa.getText();
        String ten = txtTen.getText();
        String pvi = txtPhamViVC.getText();
        int trangThai;
        if (rdoHD.isSelected()) {
            trangThai = 1;
        } else {
            trangThai = 0;
            
        }
        donViVanChuyenSerVice.update(new DonViVanChuyenViewModel(id, ma, ten, pvi, trangThai));
         JOptionPane.showMessageDialog(this, "Sửa thành công");
        this.loadTableDVVC();}
    }//GEN-LAST:event_btnSuaDVVCActionPerformed

    private void btnXoaDVVCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaDVVCActionPerformed
        String id = lbID.getText();
        donViVanChuyenSerVice.delete(new DonViVanChuyenViewModel(id, "", "", "", 0));
            int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa ko?");
        if(confirm!=JOptionPane.YES_OPTION){
            return;
        }
        JOptionPane.showMessageDialog(this, "Xóa thành công");
        this.loadTableDVVC();
    }//GEN-LAST:event_btnXoaDVVCActionPerformed

    private void btnThemDGCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDGCTActionPerformed
       if(ValidateDGCT()){ String idDG = cboDG.getSelectedItem().toString();
        String idDVVC = cboDVVC.getSelectedItem().toString();
       String idHoaDon= cboHoaDon.getSelectedItem().toString();
       String ngayGiao = txtNgayGiao.getText().toString();
         String ngayNhan = txtNgayNhan.getText().toString();
         int trangThai;
         if(rdoNhanHang.isSelected()){
             trangThai=1;
         }else{
             trangThai=0;
         }
         donGiaoChiTietSerVice.insert(new DonGiaoChiTietViewModel("", idDG, idHoaDon, idDVVC, "", "", "", "", ngayGiao, ngayNhan, trangThai));
      JOptionPane.showMessageDialog(this, "Thêm thành công");
         loadTableDGCT();}
    }//GEN-LAST:event_btnThemDGCTActionPerformed

    private void tblDGCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDGCTMouseClicked
        int row = tblDGCT.getSelectedRow();
        if (row == -1) {
            return;
        }
        String id = tblDGCT.getValueAt(row, 0).toString();
        String idDG = tblDGCT.getValueAt(row, 1).toString();
        String idHD = tblDGCT.getValueAt(row, 2).toString();
        String idDVVC = tblDGCT.getValueAt(row, 3).toString();
        String ngayGiao = tblDGCT.getValueAt(row, 8).toString();
        String ngayNhan = tblDGCT.getValueAt(row, 9).toString();
        String tinhTrang = tblDGCT.getValueAt(row, 10).toString();
        
        lbIdDGCT.setText(id);
        cboDG.setSelectedItem(idDG);
        cboHoaDon.setSelectedItem(idHD);
        cboDVVC.setSelectedItem(idDVVC);
        txtNgayGiao.setText(ngayGiao);
        txtNgayNhan.setText(ngayNhan);
        if (tinhTrang.equals("Nhận hàng")) {
            rdoNhanHang.setSelected(true);
        } else {
            rdoHuyHang.setSelected(true);
        }
        
    }//GEN-LAST:event_tblDGCTMouseClicked

    private void btnSuaDGCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDGCTActionPerformed
       if(ValidateDGCT()){   String id =lbIdDGCT.getText();
        String idDG = cboDG.getSelectedItem().toString();
        String idDVVC = cboDVVC.getSelectedItem().toString();
       String idHoaDon= cboHoaDon.getSelectedItem().toString();
       String ngayGiao = txtNgayGiao.getText().toString();
         String ngayNhan = txtNgayNhan.getText().toString();
         int trangThai;
         if(rdoNhanHang.isSelected()){
             trangThai=1;
         }else{
             trangThai=0;
         }
         donGiaoChiTietSerVice.update(new DonGiaoChiTietViewModel(id, idDG, idHoaDon, idDVVC, "", "", "", "", ngayGiao, ngayNhan, trangThai));
             JOptionPane.showMessageDialog(this, "Sửa thành công");
         loadTableDGCT();}

    }//GEN-LAST:event_btnSuaDGCTActionPerformed

    private void btnXoaDGCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaDGCTActionPerformed
      String id =lbIdDGCT.getText();
        
         donGiaoChiTietSerVice.delete(new DonGiaoChiTietViewModel(id, "", "", "", "", "", "", "", "", "", 0));
             int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa ko?");
        if(confirm!=JOptionPane.YES_OPTION){
            return;
        }
             JOptionPane.showMessageDialog(this, "Xóa thành công");
         loadTableDGCT();

    }//GEN-LAST:event_btnXoaDGCTActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSuaDG;
    private javax.swing.JButton btnSuaDGCT;
    private javax.swing.JButton btnSuaDVVC;
    private javax.swing.JButton btnThemDG;
    private javax.swing.JButton btnThemDGCT;
    private javax.swing.JButton btnThemDVVC;
    private javax.swing.JButton btnXoaDG;
    private javax.swing.JButton btnXoaDGCT;
    private javax.swing.JButton btnXoaDVVC;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JComboBox<String> cboDG;
    private javax.swing.JComboBox<String> cboDVVC;
    private javax.swing.JComboBox<String> cboHoaDon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JLabel lbID;
    private javax.swing.JLabel lbIdDGCT;
    private javax.swing.JLabel lbIdDonGiao;
    private javax.swing.JRadioButton rdoHD;
    private javax.swing.JRadioButton rdoHuyHang;
    private javax.swing.JRadioButton rdoNgungHD;
    private javax.swing.JRadioButton rdoNhanHang;
    private javax.swing.JTable tblDG;
    private javax.swing.JTable tblDGCT;
    private javax.swing.JTable tblDVVC;
    private javax.swing.JTextField txtMa;
    private javax.swing.JTextField txtMaDG;
    private javax.swing.JTextField txtMoTa;
    private javax.swing.JTextField txtNgayGiao;
    private javax.swing.JTextField txtNgayNhan;
    private javax.swing.JTextField txtPhamViVC;
    private javax.swing.JTextField txtTen;
    // End of variables declaration//GEN-END:variables

}
